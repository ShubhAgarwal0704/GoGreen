package com.example.gogreen

class Category (
    var cate : String? = "",
    var image :String? = ""
    )