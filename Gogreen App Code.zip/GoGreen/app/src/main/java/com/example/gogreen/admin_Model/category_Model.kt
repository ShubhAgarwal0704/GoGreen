package com.example.gogreen.admin_Model

class category_Model (
    var cate : String? = "",
    var image :String? = ""
    )